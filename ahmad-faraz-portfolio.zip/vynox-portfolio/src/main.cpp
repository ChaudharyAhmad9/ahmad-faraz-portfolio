#include <httplib.h>

#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>

namespace fs = std::filesystem;

std::string csv_escape(const std::string& value) {
    std::string escaped = "\"";
    for (char c : value) {
        if (c == '"') escaped += "\"\"";
        else escaped += c;
    }
    return escaped + "\"";
}

bool contains_newline(const std::string& value) {
    return value.find('\n') != std::string::npos ||
           value.find('\r') != std::string::npos;
}

int main() {
    // Serve the frontend from ./public. Set PORT in hosting environments.
    const char* port_env = std::getenv("PORT");
    const int port = port_env ? std::stoi(port_env) : 8080;
    const fs::path public_dir = fs::absolute("public");
    fs::create_directories("data");

    httplib::Server server;

    server.Get("/health", [](const httplib::Request&, httplib::Response& res) {
        res.set_content(R"({"status":"ok","service":"portfolio"})", "application/json");
    });

    server.Post("/api/contact", [](const httplib::Request& req, httplib::Response& res) {
        const std::string name = req.get_param_value("name");
        const std::string email = req.get_param_value("email");
        const std::string message = req.get_param_value("message");

        if (name.empty() || email.empty() || message.empty() ||
            name.size() > 100 || email.size() > 254 || message.size() > 5000 ||
            contains_newline(name) || contains_newline(email)) {
            res.status = 400;
            res.set_content(R"({"ok":false,"message":"Please complete all fields with valid lengths."})",
                            "application/json");
            return;
        }

        if (email.find('@') == std::string::npos || email.find('.') == std::string::npos) {
            res.status = 400;
            res.set_content(R"({"ok":false,"message":"Please enter a valid email address."})",
                            "application/json");
            return;
        }

        // Demo storage: messages are appended to data/messages.csv on the server.
        // For production, use a database and add rate limiting + spam protection.
        std::ofstream out("data/messages.csv", std::ios::app);
        if (!out) {
            res.status = 500;
            res.set_content(R"({"ok":false,"message":"The message could not be saved. Please email me instead."})",
                            "application/json");
            return;
        }
        out << csv_escape(name) << ','
            << csv_escape(email) << ','
            << csv_escape(message) << '\n';

        res.set_content(R"({"ok":true,"message":"Thanks! Your message has been received."})",
                        "application/json");
    });

    if (!fs::exists(public_dir / "index.html")) {
        std::cerr << "Could not find public/index.html. Run the server from the project root.\n";
        return 1;
    }

    server.set_mount_point("/", public_dir.string());
    std::cout << "Portfolio running at http://localhost:" << port << '\n';
    std::cout << "Press Ctrl+C to stop.\n";
    server.listen("0.0.0.0", port);
    return 0;
}
