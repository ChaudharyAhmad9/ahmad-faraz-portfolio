# Alex Morgan — C++ Portfolio Website

A responsive, dark-theme developer portfolio with a C++17 backend. The C++ server serves the frontend and accepts contact form submissions, saving them to a CSV file.

## Features
- Responsive layout for mobile, tablet and desktop
- Dark navy theme, blue/purple gradients and glass-style cards
- Home, About, Skills, Projects, Education and Contact sections
- Mobile navigation, reveal animations, smooth scrolling and back-to-top
- Contact form connected to a C++ HTTP endpoint
- Basic server-side validation and CSV message storage
- CMake build configuration

## Technology
- **Backend:** C++17 + cpp-httplib
- **Frontend:** HTML5, CSS3 and vanilla JavaScript
- **Build:** CMake

## Project structure
```text
vynox-portfolio/
├── public/
│   ├── index.html
│   ├── styles.css
│   └── script.js
├── src/
│   └── main.cpp
├── data/                 # Created automatically; contact messages saved here
├── CMakeLists.txt
├── Dockerfile
├── .gitignore
└── README.md
```

## 1. Requirements
Install:
- A C++17 compiler (GCC 9+, Clang 10+ or a recent MSVC)
- CMake 3.15+
- Git
- Internet access on the first CMake configure, because CMake downloads cpp-httplib

## 2. Build and run locally

Run these commands from the project root.

### Linux / macOS
```bash
cmake -S . -B build
cmake --build build --config Release
./build/portfolio_server
```

### Windows (Visual Studio generator)
```powershell
cmake -S . -B build
cmake --build build --config Release
.\build\Release\portfolio_server.exe
```

Open **http://localhost:8080** in your browser. The health endpoint is **http://localhost:8080/health**.

If port 8080 is already in use, set another port:
```bash
# Linux / macOS
PORT=9000 ./build/portfolio_server

# PowerShell
$env:PORT=9000
.\build\Release\portfolio_server.exe
```

When you submit the contact form, the server appends the details to `data/messages.csv`. Do not commit real visitors' personal messages to a public repository.

## 3. Personalize before submission
Search in `public/index.html` and replace:
- `Alex Morgan` and initials `AM` with your name and initials
- Introductory text with your own short bio
- `University Name`, degree/program and study dates
- `hello@example.com` with your contact email
- LinkedIn and GitHub profile URLs
- Sample project names, descriptions and GitHub links
- Skill progress indicators with honest self-assessments

The hero profile area is a designed placeholder, not a real photograph. To use your own image, add it under `public/assets/` and replace the `.avatar-placeholder` block in `index.html` with an `<img>` element, then style it in `styles.css`.

A placeholder `public/cv.pdf` is included and linked from the hero section. Replace it with your own PDF after editing your details. The link uses the browser download attribute. The example link pattern is:
```html
<a href="cv.pdf" download class="button button-ghost">Download CV ↓</a>
```
Only publish a CV after checking that it contains no private information you do not want public.

## 4. How the C++ backend works
1. `main.cpp` creates an HTTP server using cpp-httplib.
2. `set_mount_point("/", "public")` serves the website files.
3. `GET /health` provides a simple deployment health check.
4. `POST /api/contact` reads `name`, `email` and `message`, validates their presence and length, and appends them to `data/messages.csv`.
5. The browser's JavaScript sends the form with `fetch()` and displays the server response.

This is a university/demo implementation. Before real public use, add HTTPS, rate limiting, spam protection, stronger email validation, privacy/consent wording and preferably a database or secure email delivery. CSV storage is not suitable for a high-traffic production contact system.

## 5. Docker build (for hosting)
Build and run:
```bash
docker build -t my-portfolio .
docker run --rm -p 8080:8080 -e PORT=8080 my-portfolio
```
The container serves the site on port 8080. For persistent contact-message storage, configure a persistent disk/volume mounted at `/app/data` on your hosting provider.

## 6. Publish on GitHub
1. Create a new repository on GitHub, for example `cpp-personal-portfolio`.
2. Open a terminal in this folder.
3. Run:
```bash
git init
git add .
git commit -m "Build C++ personal portfolio website"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/cpp-personal-portfolio.git
git push -u origin main
```
Replace `YOUR-USERNAME` with your GitHub username.

## 7. Get a live website URL
**Important:** GitHub Pages only hosts static files. It cannot run this C++ server or the contact API. To keep the contact form functional, deploy the C++ application as a web service on a C++-capable host (for example Render, Railway, Fly.io or your own VPS).

Suggested route:
1. Push this repository to GitHub.
2. Create a new web service in your hosting provider and connect the repository.
3. Choose Docker deployment (the included `Dockerfile`).
4. Set the service to expose the port supplied through the `PORT` environment variable.
5. Add a persistent disk/volume for `/app/data` if you need CSV submissions to survive redeployments/restarts.
6. Deploy and open the HTTPS URL supplied by the host.

Hosting providers change their free tiers and deployment settings, so check current pricing and C++/Docker support before choosing. Do not deploy the contact form publicly without adding abuse protection.

### Static-only alternative
If you only need a visual demo, you can publish the `public/` folder using GitHub Pages. The portfolio layout will work, but the contact form will not be functional because GitHub Pages cannot execute `src/main.cpp`. Use a mail link or a separate form service for that static-only version.

## Academic note
This project uses C++ for the server-side application and HTML/CSS/JavaScript for the browser interface. A browser cannot directly render C++ as a webpage; the server and frontend have different responsibilities.
