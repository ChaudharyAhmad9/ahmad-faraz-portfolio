cmake_minimum_required(VERSION 3.15)
project(ModernPortfolio LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

include(FetchContent)
FetchContent_Declare(
    httplib
    GIT_REPOSITORY https://github.com/yhirose/cpp-httplib.git
    GIT_TAG v0.18.3
)
FetchContent_MakeAvailable(httplib)

add_executable(portfolio_server src/main.cpp)
target_link_libraries(portfolio_server PRIVATE httplib::httplib)
if (WIN32)
    target_link_libraries(portfolio_server PRIVATE ws2_32)
endif()
